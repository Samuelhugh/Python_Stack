class BankAccount:

    users = []

    def __init__(self, int_rate=0.01, balance=0): 
        self.int_rate = int_rate
        self.balance = balance
        BankAccount.users.append(self)
        # print(self.int_rate)
    
    def deposit(self, amount):
        self.balance += amount
        # print(self.balance, amount)
        return self
    
    def withdraw(self, amount):
        self.balance -= amount
        # print(self.balance, amount)
        return self
        if self.balance < 0:
            print('Insufficient funds: Charging a $5 Fee')
            self.balance -= 5
            # print(self.balance, amount)
    
    def display_account_info(self):
        print(f'Balance: ${self.balance}')
        return self
    
    def yield_interest(self):
        if self.balance >= 0:
            self.balance *= 1 + self.int_rate
        return self
    
    @classmethod
    def display_all_users(cls):
        for x in cls.users:
            x.display_account_info()
class User:		# here's what we have so far
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.account = BankAccount(int_rate=0.02,balance=0)
    # adding the deposit method
    def make_deposit(self, amount):	# takes an argument that is the amount of the deposit
        self.account += amount	# the specific user's account increases by the amount of the value received
    def make_withdrawal(self,amount): # the withdrawal for a specific user's account
        self.account -= amount
    def display_user_balance(self): # the display of the user's name and account balance printed in one line
        print(f'User: Name: {self.name}, Balance: {self.account}')
    def transfer_money(self,other_user,amount):
        other_user.account += amount
        self.account -= amount
sam = BankAccount()
tyson = BankAccount()